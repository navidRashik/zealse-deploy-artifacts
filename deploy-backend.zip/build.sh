#!/usr/bin/env bash
# Build step for the Hostinger Node deploy pipeline — GO ONLY.
# The runtime dir only receives the archive contents (NOT build artifacts);
# this step sanity-checks the payload. The Go backend is a prebuilt static
# binary — there is nothing to compile on the host and no Python bootstrap.
set -euo pipefail
cd "$(dirname "$0")"

echo "[build] sanity checks (pwd=$(pwd))"
check() { test -e "$1" || { echo "[build] MISSING: $1"; exit 1; }; }
check gateway/server.js
check package.json
check bin/backend-go
test -x bin/backend-go || chmod +x bin/backend-go
test -x gateway/start_backend.sh || chmod +x gateway/start_backend.sh
if [ -d app ]; then
  check app/index.html
  echo "[build] OK — Go backend + dashboard static export (/app)"
else
  echo "[build] OK — Go backend only (no /app static export in archive)"
fi
