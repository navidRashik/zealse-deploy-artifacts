/**
 * chatroom API gateway for Hostinger shared hosting — GO ONLY.
 *
 * Hostinger's Node.js runtime only runs a Node entrypoint, so this module
 * owns the public port and reverse-proxies everything to the Go backend
 * (backend-go, static binary) bound to 127.0.0.1:3101. No npm dependencies.
 *
 * - Spawns `gateway/start_backend.sh` once at startup (which execs
 *   ./bin/backend-go with the right env mapping).
 * - Resilient: any request that arrives while the child is down triggers a
 *   respawn; the child also respawns on unexpected exit (with backoff).
 * - Pipes method/headers/body both ways (streaming, no buffering).
 * - Serves the dashboard static export from ./app when present (URL prefix
 *   /app — the dashboard is built with NEXT_OUTPUT=export, basePath=/app).
 * - GET /gateway-health returns child pid + uptime for ops.
 * - GET /gateway-diag?token=… returns a ring buffer of recent lines (only
 *   when DIAG_TOKEN is set) — the window into boot failures on a host whose
 *   runtime logs are not exposed.
 * - Child stdout/stderr is piped to console.* so it lands in the Hostinger
 *   runtime logs.
 */

'use strict';

const { spawn } = require('child_process');
const http = require('http');
const path = require('path');
const os = require('os');
const fs = require('fs');

const APP_ROOT = path.resolve(__dirname, '..');
const UPSTREAM_HOST = '127.0.0.1';
const UPSTREAM_PORT = parseInt(process.env.UPSTREAM_PORT || '3101', 10);
const PORT = parseInt(process.env.PORT || '3000', 10);
const STATIC_ROOT = path.join(APP_ROOT, 'app'); // dashboard export (optional)
const STATIC_PREFIX = '/app';

// The launcher records which runtime it is starting and why; surfacing it
// here makes a remote deploy diagnosable without shell access.
function readRuntimeStatus() {
  try {
    return fs.readFileSync(path.join(APP_ROOT, '.backend_runtime_status'), 'utf8').trim();
  } catch {
    return null;
  }
}

function childCommand() {
  return { cmd: 'bash', args: [path.join(__dirname, 'start_backend.sh')] };
}

const RESPAWN_BACKOFF_MS = 2000;
const RESPAWN_MAX_MS = 30000;
let respawnDelay = RESPAWN_BACKOFF_MS;

let child = null;
let childStartedAt = 0;
let childRespawns = 0;
let spawning = false;

function log(...args) {
  const line = `[gateway ${new Date().toISOString()}] ${args.join(' ')}`;
  console.log(line);
  diag(line);
}

function logErr(...args) {
  const line = `[gateway ${new Date().toISOString()}] ${args.join(' ')}`;
  console.error(line);
  diag(line);
}

// Ring buffer of the last gateway/child lines, served at /gateway-diag when
// DIAG_TOKEN is set — the only window into boot failures on a host whose
// runtime logs the API does not expose.
const DIAG_LIMIT = 300;
const diagLines = [];
function diag(line) {
  diagLines.push(`${new Date().toISOString()} ${line}`);
  if (diagLines.length > DIAG_LIMIT) diagLines.shift();
}

function spawnChild(reason) {
  if (child || spawning) return;
  spawning = true;
  const { cmd, args } = childCommand();
  log(`spawning backend (${reason}): ${cmd} ${args.join(' ')}`);
  let c;
  try {
    c = spawn(cmd, args, {
      cwd: APP_ROOT,
      env: process.env,
      stdio: ['ignore', 'pipe', 'pipe'],
    });
  } catch (err) {
    spawning = false;
    logErr('spawn failed:', err && err.message);
    scheduleRespawn('spawn-threw');
    return;
  }
  spawning = false;
  child = c;
  childStartedAt = Date.now();
  respawnDelay = RESPAWN_BACKOFF_MS; // reset backoff on a successful start
  log(`backend child pid=${c.pid}`);

  const tag = `[backend ${c.pid}]`;
  c.stdout.on('data', (d) => {
    String(d).split('\n').filter(Boolean).forEach((l) => { console.log(tag, l); diag(`${tag} ${l}`); });
  });
  c.stderr.on('data', (d) => {
    String(d).split('\n').filter(Boolean).forEach((l) => { console.error(tag, l); diag(`${tag} ${l}`); });
  });
  c.on('error', (err) => {
    logErr('child error event:', err && err.message);
    // Spawn-phase failures (EAGAIN under CloudLinux process limits, ENOENT,
    // EACCES) emit 'error' WITHOUT a following 'exit'. The default flow
    // therefore parks a dead child object in `child` forever: every later
    // ensureChild() sees a non-null child and never respawns, so the upstream
    // stays down until the gateway itself is restarted (seen in production
    // 2026-09-19, chatapi). Clear the reference and respawn with backoff;
    // scheduleRespawn's timer guard dedupes when 'exit' also fires.
    child = null;
    scheduleRespawn(`child error: ${err && err.message}`);
  });
  c.on('exit', (code, signal) => {
    logErr(`backend child pid=${c.pid} exited code=${code} signal=${signal} after ${((Date.now() - childStartedAt) / 1000).toFixed(1)}s`);
    child = null;
    scheduleRespawn(`exit code=${code} signal=${signal}`);
  });
}

function scheduleRespawn(reason) {
  if (respawnTimer) return;
  respawnDelay = Math.min(respawnDelay * 2, RESPAWN_MAX_MS);
  childRespawns += 1;
  respawnTimer = setTimeout(() => {
    respawnTimer = null;
    spawnChild(reason);
  }, RESPAWN_BACKOFF_MS);
  log(`will respawn in ${RESPAWN_BACKOFF_MS}ms (${reason})`);
}

let respawnTimer = null;
function ensureChild() {
  if (!child && !spawning && !respawnTimer) spawnChild('request-while-down');
}

// ---------------------------------------------------------------- static /app

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.mjs': 'application/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.webp': 'image/webp',
  '.avif': 'image/avif',
  '.ico': 'image/x-icon',
  '.txt': 'text/plain; charset=utf-8',
  '.xml': 'application/xml; charset=utf-8',
  '.map': 'application/json; charset=utf-8',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.ttf': 'font/ttf',
  '.eot': 'application/vnd.ms-fontobject',
  '.otf': 'font/otf',
  '.wasm': 'application/wasm',
  '.webmanifest': 'application/manifest+json',
};

// Resolve a URL path under /app to a file on disk: exact file → path+".html"
// → path+"/index.html" → /app/index.html (SPA root fallback).
function resolveStaticFile(urlPath) {
  let rel = urlPath.slice(STATIC_PREFIX.length); // strip /app
  try { rel = decodeURIComponent(rel); } catch { /* keep raw */ }
  rel = rel.replace(/\/+$/, '');
  const candidates = [];
  if (rel === '' || rel === '/') {
    candidates.push('index.html');
  } else {
    candidates.push(rel);
    candidates.push(`${rel}.html`);
    candidates.push(`${rel}/index.html`);
  }
  for (const cand of candidates) {
    const abs = path.join(STATIC_ROOT, cand);
    if (!abs.startsWith(STATIC_ROOT + path.sep) && abs !== STATIC_ROOT) continue; // traversal guard
    try {
      const st = fs.statSync(abs);
      if (st.isFile()) return { abs, rel: cand };
    } catch { /* try next */ }
  }
  // SPA fallback: unknown routes fall back to the dashboard root so client
  // navigation never 404s (Next client router takes over).
  const fallback = path.join(STATIC_ROOT, 'index.html');
  try {
    if (fs.statSync(fallback).isFile()) return { abs: fallback, rel: 'index.html' };
  } catch { /* no static export deployed */ }
  return null;
}

function serveStatic(req, res) {
  const parsed = new URL(req.url, 'http://localhost');
  const found = resolveStaticFile(parsed.pathname);
  if (!found) {
    res.writeHead(404, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ detail: 'static export not found (deploy archive without app/?)' }));
    return;
  }
  const ext = path.extname(found.abs).toLowerCase();
  const isAsset = parsed.pathname.startsWith(`${STATIC_PREFIX}/_next/`);
  res.writeHead(200, {
    'Content-Type': MIME[ext] || 'application/octet-stream',
    'Cache-Control': isAsset ? 'public, max-age=31536000, immutable' : 'no-cache',
  });
  fs.createReadStream(found.abs)
    .on('error', (err) => {
      logErr('static read error:', err && err.message);
      try { res.destroy(err); } catch { /* noop */ }
    })
    .pipe(res);
}

function wantsStatic(req) {
  if (!req.url || !req.url.startsWith(STATIC_PREFIX)) return false;
  // Prefix-boundary check: /app, /app/ and /app/** are documents/assets;
  // /application-style paths fall through to the API proxy.
  const rest = req.url.slice(STATIC_PREFIX.length);
  return rest === '' || rest.startsWith('/');
}

// -------------------------------------------------------------------- server

spawnChild('startup');

const server = http.createServer((req, res) => {
  if (req.url && req.url.startsWith('/gateway-diag')) {
    const want = process.env.DIAG_TOKEN;
    const got = new URL(req.url, 'http://localhost').searchParams.get('token') || '';
    if (!want || got !== want) {
      res.writeHead(404, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ detail: 'not found' }));
      return;
    }
    const body = JSON.stringify({
      lines: diagLines,
      child_pid: child ? child.pid : null,
      child_uptime_s: child ? Math.round((Date.now() - childStartedAt) / 1000) : null,
      child_respawns: childRespawns,
      now: new Date().toISOString(),
    });
    res.writeHead(200, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' });
    res.end(body);
    return;
  }

  if (req.url === '/gateway-health') {
    const body = JSON.stringify({
      ok: true,
      pid: process.pid,
      node: process.version,
      upstream: `${UPSTREAM_HOST}:${UPSTREAM_PORT}`,
      backendRuntime: readRuntimeStatus(),
      staticApp: fs.existsSync(path.join(STATIC_ROOT, 'index.html')),
      child_pid: child ? child.pid : null,
      child_uptime_s: child ? Math.round((Date.now() - childStartedAt) / 1000) : null,
      child_respawns: childRespawns,
      hostname: os.hostname(),
      now: new Date().toISOString(),
    });
    res.writeHead(200, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' });
    res.end(body);
    return;
  }

  if (wantsStatic(req) && req.method === 'GET') {
    serveStatic(req, res);
    return;
  }

  ensureChild();

  const headers = { ...req.headers };
  headers.host = `${UPSTREAM_HOST}:${UPSTREAM_PORT}`;
  const ip = (req.socket.remoteAddress || '').replace(/^::ffff:/, '');
  if (ip) {
    const prev = req.headers['x-forwarded-for'];
    headers['x-forwarded-for'] = prev ? `${prev}, ${ip}` : ip;
    headers['x-forwarded-proto'] = req.headers['x-forwarded-proto'] || 'https';
  }
  if (headers.expect) delete headers.expect; // avoid 417 from upstream

  const upstream = http.request(
    {
      host: UPSTREAM_HOST,
      port: UPSTREAM_PORT,
      path: req.url,
      method: req.method,
      headers,
    },
    (upRes) => {
      res.writeHead(upRes.statusCode || 502, upRes.headers);
      upRes.pipe(res);
      upRes.on('error', (err) => {
        logErr('upstream response error:', err && err.message);
        try { res.destroy(err); } catch (_) { /* noop */ }
      });
    }
  );

  upstream.on('error', (err) => {
    logErr('proxy error for', req.method, req.url, '-', err && err.message);
    if (!res.headersSent) {
      res.writeHead(502, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ detail: 'upstream unavailable (backend not ready)' }));
    } else {
      try { res.destroy(); } catch (_) { /* noop */ }
    }
  });

  req.pipe(upstream);
  req.on('error', (err) => {
    logErr('client request error:', err && err.message);
    try { upstream.destroy(); } catch (_) { /* noop */ }
  });
});

// WebSocket upgrades are blocked at the Hostinger edge anyway; reject them
// cleanly instead of leaving sockets hanging.
server.on('upgrade', (req, socket) => {
  logErr('websocket upgrade rejected:', req.url);
  try {
    socket.write('HTTP/1.1 501 Not Implemented\r\nConnection: close\r\n\r\n');
  } catch (_) { /* noop */ }
  socket.destroy();
});

server.listen(PORT, () => {
  log(`gateway listening on port ${PORT}, proxying to ${UPSTREAM_HOST}:${UPSTREAM_PORT}, app root ${APP_ROOT}`);
});

process.on('uncaughtException', (err) => logErr('uncaughtException:', err && (err.stack || err.message)));
process.on('unhandledRejection', (err) => logErr('unhandledRejection:', err && (err.stack || err.message)));
