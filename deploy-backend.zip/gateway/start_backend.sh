#!/usr/bin/env bash
# chatroom backend launcher for Hostinger shared hosting.
#
# Prefers the Go backend (static linux binary — instant boot, no Python
# bootstrap) and falls back to the Python/uvicorn self-healer when the binary
# is absent, or when it fails to boot three times within ten minutes: a crash
# loop must degrade to the last known-good runtime, not take the API down
# with it. Full rollback is a redeploy of the same archive without the binary.
#
# Env mapping: Hostinger sets SECRET_KEY / UPSTREAM_PORT; the Go backend wants
# ZV_SECRET / ZV_ADDR / ZV_DB_PATH.
set -uo pipefail
cd "$(dirname "$0")/.."

STRIKES_FILE=".go_boot_strikes"
MAX_STRIKES=3
STRIKE_WINDOW=600  # seconds

read_state() {
  local last count
  last=$(cut -d' ' -f1 "$STRIKES_FILE" 2>/dev/null || true)
  count=$(cut -d' ' -f2 "$STRIKES_FILE" 2>/dev/null || echo 0)
  [ -z "$count" ] && count=0
  if [ -n "$last" ] && [ $(( $(date +%s) - last )) -gt "$STRIKE_WINDOW" ]; then
    count=0
  fi
  echo "$count"
}

record_failure() {
  echo "$(date +%s) $(( $(read_state) + 1 ))" > "$STRIKES_FILE"
}

STATUS_FILE=".backend_runtime_status"

write_status() { echo "$1 | $(date -u +%H:%M:%S)" > "$STATUS_FILE" 2>/dev/null || true; }

# Deploy pipelines may normalize file modes, so restore the exec bit rather
# than silently falling back to Python over a lost +x.
chmod +x ./bin/backend-go 2>/dev/null || true

# Go is the preferred runtime, but the strike limiter may only route to the
# Python fallback when that fallback actually ships: the Go-only archive has
# no start_uvicorn.sh, and routing to a missing fallback just crash-loops
# exit 127 until the strikes age out (seen in production 2026-09-19, chatapi
# restart churn burned 3 strikes and took the API down for the window).
if [ -x ./bin/backend-go ] && { [ "$(read_state)" -lt "$MAX_STRIKES" ] || [ ! -f gateway/start_uvicorn.sh ]; }; then
  # Persistent data dir: the versioned runtime dir is wiped on every deploy,
  # which reset the production DB each time. The domains dir survives.
  DATA_DIR="${HOME}/data"
  mkdir -p "$DATA_DIR"
  export ZV_DB_PATH="${ZV_DB_PATH:-$DATA_DIR/chatroom.db}"
  # One-time carry-over of the pre-persistence database so existing users
  # (and their bcrypt hashes) survive the first persistent-path deploy.
  if [ ! -s "$ZV_DB_PATH" ] && [ -s dev.db ]; then
    cp dev.db "$ZV_DB_PATH"
  fi
  export ZV_ADDR="127.0.0.1:${UPSTREAM_PORT:-3101}"
  [ -n "${SECRET_KEY:-}" ] && export ZV_SECRET="$SECRET_KEY"
  write_status "go: starting (db=$ZV_DB_PATH)"
  echo "[start_backend $(date -u +%H:%M:%S)] starting Go backend (db=$ZV_DB_PATH addr=$ZV_ADDR)"
  ./bin/backend-go
  rc=$?
  record_failure
  write_status "go: exited rc=$rc strikes=$(read_state) — next boot may use python"
  echo "[start_backend $(date -u +%H:%M:%S)] Go backend exited rc=$rc (strikes=$(read_state)) — respawning; Python takes over after $MAX_STRIKES"
  exit "$rc"
fi

write_status "python: starting (go absent or strike-limited)"
echo "[start_backend $(date -u +%H:%M:%S)] starting Python backend (uvicorn self-healer)"
exec bash gateway/start_uvicorn.sh
