'use strict';
// Zealse Connect dashboard — static file server for the Next.js export.
// The export is built with basePath /app, so every URL carries that prefix;
// strip it, serve the file, and fall back through .html and index.html.
const http = require('http');
const fs = require('fs');
const path = require('path');

const PUBLIC = path.join(__dirname, 'public');
const PORT = parseInt(process.env.PORT || '3000', 10);

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
  '.txt': 'text/plain; charset=utf-8',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
};

function resolveFile(urlPath) {
  let pathname = decodeURIComponent(urlPath.split('?')[0]);
  if (pathname.startsWith('/app')) pathname = pathname.slice(4) || '/';
  let rel = pathname === '/' ? '/index.html' : pathname;
  const candidates = [rel, rel.replace(/\/$/, '') + '/index.html', rel + '.html'];
  for (const cand of candidates) {
    const file = path.join(PUBLIC, path.normalize(cand).replace(/^(\.\.[\/\\])+/, ''));
    if (file.startsWith(PUBLIC) && fs.existsSync(file) && fs.statSync(file).isFile()) {
      return file;
    }
  }
  return null;
}

http.createServer((req, res) => {
  const file = resolveFile(req.url || '/');
  if (file) {
    const body = fs.readFileSync(file);
    res.writeHead(200, {
      'Content-Type': MIME[path.extname(file).toLowerCase()] || 'application/octet-stream',
      'Content-Length': body.length,
      'Cache-Control': file.endsWith('.html') ? 'no-cache' : 'public, max-age=3600',
    });
    res.end(req.method === 'HEAD' ? undefined : body);
    return;
  }
  res.writeHead(404, { 'Content-Type': 'text/plain' });
  res.end('Not found');
}).listen(PORT, '127.0.0.1', () => {
  console.log(`[zealse-connect-web] listening on 127.0.0.1:${PORT}`);
});
